package idea3;

public class Main {

}
