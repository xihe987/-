package idea3;

public class SubSystemTwo {

}
