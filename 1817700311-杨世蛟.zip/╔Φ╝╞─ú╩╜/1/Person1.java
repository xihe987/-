package idea;

public class Person1 {
	private String	name;

	public Person1(String name)
	{
		this.name = name;
	}

	public void show()
	{
		System.out.println("装扮的" + name);
	}
}
