package lishi;

public class khd {
    public static void main(String[] args) {
        Animal animal = new Dog();
        animal.getChi();
        animal.getHe();
        animal.getJiao();
        animal.getPao();
    }
}
