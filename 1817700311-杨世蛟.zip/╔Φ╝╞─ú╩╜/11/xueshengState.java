package guanchazhe;

public class xueshengState extends Guanchazhe{

    // 具体被观察者状态
    private String	xueshengState;
    public String getxueshengState()
    {
        return xueshengState;
    }

    public void setXueshengState(String xueshengState)
    {
        this.xueshengState = xueshengState;
    }
}
