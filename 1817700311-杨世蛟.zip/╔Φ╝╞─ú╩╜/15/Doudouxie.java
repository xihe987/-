package zhuangshi;

public class Doudouxie extends Chuanda{
    public void show() {
        super.show();
        System.out.println("豆豆鞋");
    }
}
