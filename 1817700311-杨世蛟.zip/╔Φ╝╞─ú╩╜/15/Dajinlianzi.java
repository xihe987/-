package zhuangshi;

public class Dajinlianzi extends Chuanda{
    public void show() {
        super.show();
        System.out.println("大金链子");
    }
}
