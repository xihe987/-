package zhuangshi;

public class Jinshenku extends Chuanda{
    public void show() {
        super.show();
        System.out.println("紧身裤");
    }
}
