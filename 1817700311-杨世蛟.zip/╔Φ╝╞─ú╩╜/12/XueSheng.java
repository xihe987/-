package dimite;
public class XueSheng {
    public String name;
    public XueSheng(String name) {
        this.name = name;
    }
    public void work() {
        System.out.println(name + "打扫了卫生");
    }
}
