package chaoshiquan;

public class Xuesheng2 extends Shijuana {
    @Override
    protected String answer1() {
        return "b";
    }
    @Override
    protected String answer2() {
        return "b";
    }
    @Override
    protected String answer3() {
        return "c";
    }
}
