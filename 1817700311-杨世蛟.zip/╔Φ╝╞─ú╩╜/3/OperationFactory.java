package idea2;

public class OperationFactory {

}
