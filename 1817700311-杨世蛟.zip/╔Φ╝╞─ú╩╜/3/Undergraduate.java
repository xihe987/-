package idea2;

public class Undergraduate {

}
