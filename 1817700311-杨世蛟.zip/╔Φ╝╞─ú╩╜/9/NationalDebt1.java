/**
 * @Classname NationalDebt1
 * @Description TODO
 * @Author 马维俊
 * @Version V1.0.0
 * @Date 2019/5/6 15:08
 */
public class NationalDebt1 {
    public void sell()
    {
        System.out.println("国债1卖出");
    }

    public void buy()
    {
        System.out.println("国债1买入");
    }
}
