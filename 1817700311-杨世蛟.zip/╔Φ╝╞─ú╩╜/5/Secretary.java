package idea4;

public class Secretary {

}
