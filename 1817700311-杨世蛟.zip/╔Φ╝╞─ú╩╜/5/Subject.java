package idea4;

public interface Subject {

}
