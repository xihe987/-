public interface Jk {
    void getfellow();
     void getqiaokeli();
     void getxiaodao();
}
