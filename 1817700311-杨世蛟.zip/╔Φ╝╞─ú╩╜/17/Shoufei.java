package celue;

public interface Shoufei {
    public double shoufei(double money);

}
