package idea1;

public class Main {

}
