package idea1;

public class Proxy {

}
