package idea1;

public interface GiveGift {

}
