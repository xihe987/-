public interface CashSuper {
    public double acceptCash(double money);
}
